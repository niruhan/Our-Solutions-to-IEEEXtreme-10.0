originalPassword = raw_input()
times = input()
for i in range(times):
    temp = raw_input()
    tempList = [int(x) for x in temp.split()]
    if tempList[0] == 1:
        i = tempList[1]
        j = tempList[2] + 1
        k = tempList[3]
        if (originalPassword[i:j] == originalPassword[k:k + j - i]):
            print'Y'
        else:
            print 'N'

    elif tempList[0] == 2:
        i = tempList[1] - 1
        j = tempList[2]
        k = tempList[3] - 1
        originalPassword = originalPassword[0:i] + originalPassword[k:k + j - 1] + originalPassword[j::]

    elif tempList[0] == 3:
        i = tempList[1] - 1
        j = tempList[2]
        for m in range(i, j):
            if originalPassword[m] == "z":
                originalPassword = originalPassword[0:m] + "a" + originalPassword[m + 1::]
            else:
                originalPassword = originalPassword[0:m] + chr(ord(originalPassword[m]) + 1) + originalPassword[m + 1::]