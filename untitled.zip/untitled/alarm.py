a = "11/21/2016 13:34"
b = "11/21/2016 15:34"

def Comparator(stamp1, stamp2):
    stamp1 = stamp1.split(" ")
    stamp2 = stamp2.split(" ")
    date1 = stamp1[0]
    date2 = stamp2[0]
    time1 = stamp1[1]
    time2 = stamp2[1]
    date1 = date1.split("/")
    date2 = date2.split("/")
    time1 = time1.split(":")
    time2 = time2.split(":")
    weight1 = 0;
    weight2 = 0;
    if (int(time1[1]) > int(time2[1])):
        weight1+=1
    elif (int(time1[1]) < int(time2[1])):
        weight2+=1

    if (int(time1[0]) > int(time2[0])):
        weight1+=10
    elif (int(time1[0]) < int(time2[0])):
        weight2+=10

    if (int(date1[1]) > int(date2[1])):
        weight1+=100
    elif (int(date1[1]) < int(date2[1])):
        weight2+=100

    if (int(date1[0]) > int(date2[0])):
        weight1+=1000
    elif (int(date1[0]) < int(date2[0])):
        weight2+=1000

    if (int(date1[2]) > int(date2[2])):
        weight1+=10000
    elif (int(date1[2]) < int(date2[2])):
        weight2+=10000

    if weight1 > weight2:
        return True
    else:
        return False

print Comparator(a, b)