#a=[1, 3, 5]
#b=[3,7]
#c=[a,b]

def numPlayable(array):
    numPlay = 0;
    for i in range(len(array)):
        numPlay += ((array[i] - 1) / 2)
    return numPlay

numGames = int(raw_input())
for j in range(numGames):
    numPiles = int(raw_input())
    numPlay = 0
    for i in range(numPiles):
        bluff = raw_input()
        pileList=raw_input()
        pileList = pileList.split(" ")
        pileList = map(int, pileList)

        numPlay+=numPlayable(pileList)
        #print numPlay

    if (numPlay%2 == 1):
        print "Alice"
    else:
         print "Bob"