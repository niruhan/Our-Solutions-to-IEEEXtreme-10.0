a=[[1,0],[2,0],[3,0],[4,0],[5]]
i=0
n = len(a)
while(len(a)>1):
    print "length"
    print len(a)
    print "index"
    index = i % len(a)
    print index
    if (index % 2 == 1):
        a.__delitem__(index)
        i+=1
    else:
        i+=1
#print a

