a=[3,5,1,1,6,7,4,4,9,3]
b=set(a)
b=list(b)
b.sort()

print b
def disturbanceFinder(array, mid):
    midIndex1 = mid
    midIndex2 = midIndex1+1

    mid1 = b[midIndex1]
    mid2 = b[midIndex2]

    disturbance = mid1-array[0] + array[-1] - mid2
    return disturbance

testMid = len(b)/2
currentDisturbance = disturbanceFinder(b, testMid)
RHSMid =testMid+1

for i in range(RHSMid, len(b)-1):
    print i
    nextDisturbance = disturbanceFinder(b, i)
    #print nextDisturbance
    bestRHSMid = i
    if nextDisturbance > currentDisturbance:
        break

print bestRHSMid

#print disturbanceFinder(b, 5)