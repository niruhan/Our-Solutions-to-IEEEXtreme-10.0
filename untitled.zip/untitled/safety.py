
def EqualityChecker(i, j, k):

    if (b[i:j] == b[k:j+1-i]):
        print "Y"
    else:
        print "N"

def Replacer(i,j,k):
    c = b[0:i] + a[k:k+j-i] + b[j:]
    return c

def ReplaceLetter(index, myList):
    if myList[index] == "z":
        to = "a"
    else:
        to = chr(ord(myList[index]) + 1)
    c = myList[:index] + to + myList[index+1:]
    return c

def ReplaceSubString(i,j, myList):
    c = myList
    for x in range(i,j):
        #print x
        c = ReplaceLetter(x, c)
        #print c
    return c

a=raw_input()
numOps = int(raw_input())
#a="bbbbxrzbzcj"
b=(a+".")[:-1]

for q in range(numOps):
    #print b
    operation = raw_input()
    operation = operation.split(" ")
    operation = map(int, operation)
    i = operation[1] - 1
    j= operation[2]
    if (len(operation) == 4):
        k= operation[3] -1
    if (operation[0] == 1):
        EqualityChecker(i, j, k)
    elif (operation[0] == 2):
        b = Replacer(i,j,k)
    elif operation[0] == 3:
        b = ReplaceSubString(i,j,b)

#print b

