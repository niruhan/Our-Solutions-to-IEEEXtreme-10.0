#a=[[0],[0],[0],[0],[0],[3]]

while True:
    try:
        temp = raw_input()
    except EOFError:
        break
    a=[]

    temp = temp.split(" ")
    numPosts = int(temp[1])
    for i in range(numPosts):
        new = raw_input()
        a.append([int(new)])
    thread=[]
    target = int(temp[0])
    b=[0]
    b1=[0]

    for i in range(len(a)):
        if a[i][0] == 0:
            thread.append(1)
            a[i].append(len(thread)-1)
        else:
            post = a[i][0]
            page = a[post-1][1]
            thread[page] +=1
            a[i].append(page)

    b = [[]]
    z = 0
    for i in range(len(thread)):
        if sum(b[z]) < target:
            b[z].append(thread[i])
        else:
            b.append([thread[i]])
            z += 1

    b.reverse()
    print b
    sumList = []



    maximumDif = abs(max(sumList) - target)
    minimumDif = abs(min(sumList) - target)
    print max(maximumDif, minimumDif)
