from math import log

def niruhan(n):

    if n == 1:
        return 1
    if n == 2:
        return 1

    Logarithm = log(n, 2)
    #print Logarithm

    if not Logarithm.is_integer():
        m = int(Logarithm)
        #print m
        R = n - int(pow(2, m))

        return 2*R +1
    else:

        return 1

print int(pow(2, 34))