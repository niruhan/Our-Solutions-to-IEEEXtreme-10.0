a="bbbbxrzbzcj"
b=(a+".")[:-1]

i=1
j=5
k=6
def Replacer(i,j,k):
    c = b[0:i] + a[k:k+j-i] + b[j:]
    return c

print Replacer(i,j,k)