from math import log

def niruhan(n):

    if n == 1:
        return 1
    if n == 2:
        return 1

    Logarithm = log(n, 2)
    print Logarithm

    if not Logarithm.is_integer():
        m = int(Logarithm) +1
        R = n - int(pow(2, m))

        return 2*R +1
    else:

        return 1

num = input()

for i in range(num):
    var = input()
    r = niruhan(var)
    print r