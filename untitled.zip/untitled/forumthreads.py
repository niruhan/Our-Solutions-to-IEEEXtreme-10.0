#a=[[0],[0],[0],[0],[0],[3]]

while True:
    try:
        temp = raw_input()
    except EOFError:
        break
    a=[]

    temp = temp.split(" ")
    numPosts = int(temp[1])
    for i in range(numPosts):
        new = raw_input()
        a.append([int(new)])
    thread=[]
    target = int(temp[0])
    b=[0]
    b1=[0]

    for i in range(len(a)):
        if a[i][0] == 0:
            thread.append(1)
            a[i].append(len(thread)-1)
        else:
            post = a[i][0]
            page = a[post-1][1]
            thread[page] +=1
            a[i].append(page)

    thread.reverse()

    #print thread
    specialList=[]
    for i in range(len(thread)):
        if b[-1] + thread[i] <=target:
            b[-1]+= thread[i]

        elif abs(b[-1] + thread[i] - target) <= abs(target - b[-1]):
            specialList.append([len(b)-1])
            specialList[-1].append(thread[i])
            b[-1] += thread[i]

        else:

            b.append(thread[i])

    #print b

    #print specialList

    for i in range(len(specialList)):
        comp1 = abs(b[specialList[i][0]] - specialList[i][1] - target)
        comp2 = abs(b[specialList[i][0]+1] + specialList[i][1] - target)

        if comp1>comp2:
            b[specialList[i][0]+1] += specialList[i][1]
            b[specialList[i][0]] -= specialList[i][1]
    #print b

    maximumDif = abs(max(b) - target)
    minimumDif = abs(min(b) - target)
    print max(maximumDif, minimumDif)
