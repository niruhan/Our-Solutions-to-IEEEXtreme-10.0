from threading import Timer


def time_up():
    answer= None
    print 'time up...'
    break


def raw_input_with_timeout(x):

    t = Timer(x,time_up) # x is amount of time in seconds
    t.start()
    try:
        answer = raw_input("enter answer : ")
    except Exception:
        print 'pass\n'
        answer = None

    if answer != True:   # it means if variable have somthing
        t.cancel()       # time_up will not execute(so, no skip)

    return answer

a = raw_input_with_timeout(5) # try this for five seconds
print a
