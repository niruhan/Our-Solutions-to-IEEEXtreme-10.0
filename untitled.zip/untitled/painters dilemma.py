
def FindIndex (list1, element) :
    try:
        ind = list1.index(element)
        return ind
    except ValueError:
        return len(list1) + 5

#a = [9, 1, 7, 6, 9, 9, 8, 7, 6, 7]

#a= [7, 7, 2, 11, 7]

times = raw_input()
times = int(times)

for x in range(times):

    num=raw_input()
    temp=raw_input()
    a = [int(x) for x in temp.split()]
    #print a

    b1=0
    b2=0
    change=0

    for i in range(len(a)):
        #print a[i]
        #print (b1,b2)
        if (b1 == a[i] or b2 == a[i]):
            #print "match brush found"
            continue
        elif (b1 == 0):
            b1=a[i]
            change+=1
            #continue
        elif (b2 == 0):
            b2=a[i]
            change+=1
            #continue
        else:
            #print "enter try catch"
            b1r = FindIndex(a[i+1:], b1)
            b2r = FindIndex(a[i + 1:], b2)
            #print b1r, b2r

            if (b1r>len(a[i+1:]) and b2r>len(a[i+1:])):
                b1 = a[i]
                change+=1

            elif b1r<b2r :
                b2 = a[i]
                change+=1
            else:
                b1 = a[i]
                change+=1



    print change

