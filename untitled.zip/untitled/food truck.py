import math
from operator import itemgetter

def GetDistance(lat1, long1, lat2, long2):
    lat1 = math.radians(lat1)
    lat2 = math.radians(lat2)
    long1 = math.radians(long1)
    long2 = math.radians(long2)
    a = math.sin((lat1-lat2)/2)
    a = a**2

    b1= math.cos(lat1) * math.cos(lat2)
    b2 = math.sin((long1-long2)/2)
    b2 = b2**2

    b = b1*b2

    sq = math.sqrt(a+b)
    dist = 2*earth * math.asin(sq)
    return dist

def IsLessThan(lat, long, radius):
    entryList = entry.split(",")
    testLat = float(lat)
    testLong = float(long)
    dist = GetDistance(foodLat, foodLong, testLat, testLong)
    #print dist
    if (dist<radius):
        return True
    else:
        return False
    #print entryList

def Comparator(stamp1, stamp2):
    stamp1 = stamp1.split(" ")
    stamp2 = stamp2.split(" ")
    date1 = stamp1[0]
    date2 = stamp2[0]
    time1 = stamp1[1]
    time2 = stamp2[1]
    date1 = date1.split("/")
    date2 = date2.split("/")
    time1 = time1.split(":")
    time2 = time2.split(":")
    weight1 = 0;
    weight2 = 0;
    if (int(time1[1]) > int(time2[1])):
        weight1+=1
    elif (int(time1[1]) < int(time2[1])):
        weight2+=1

    if (int(time1[0]) > int(time2[0])):
        weight1+=10
    elif (int(time1[0]) < int(time2[0])):
        weight2+=10

    if (int(date1[1]) > int(date2[1])):
        weight1+=100
    elif (int(date1[1]) < int(date2[1])):
        weight2+=100

    if (int(date1[0]) > int(date2[0])):
        weight1+=1000
    elif (int(date1[0]) < int(date2[0])):
        weight2+=1000

    if (int(date1[2]) > int(date2[2])):
        weight1+=10000
    elif (int(date1[2]) < int(date2[2])):
        weight2+=10000

    if weight1 > weight2:
        return True
    else:
        return False

earth = 6378.137
#foodLat = 18.9778972
#foodLong = 72.8321983
lat2 = 18.912875
long2=72.822318
#radius =1
entry = "10/21/2016 13:34,18.912875,72.822318,9020320100"
lines = []
advertiseNumbers=[]

truck = raw_input()
truck = truck.split(",")
foodLat = float(truck[0])
foodLong = float(truck[1])

radius = raw_input()
radius = float(radius)
bluff = raw_input()

while True:
    try:
        line = raw_input()
    except EOFError:
        break
    if line:
        lines.append(line)
    else:
        break


for i in range(len(lines)):
    lines[i] = lines[i].split(",")
    lines[i][3] = int(lines[i][3])

lines = sorted(lines, key=itemgetter(3))



cleanedLines =[lines[0]]

for i in range(1,len(lines)):
    if cleanedLines[-1][3] == lines[i][3]:
        if Comparator(lines[i][0], cleanedLines[-1][0]):
            #print cleanedLines
            cleanedLines.pop()
            cleanedLines.append(lines[i])
    else:
        cleanedLines.append(lines[i])

#print cleanedLines

for i in range(len(cleanedLines)):
    lat = cleanedLines[i][1]
    long = cleanedLines[i][2]

    if IsLessThan(lat, long, radius):
        advertiseNumbers.append(str(cleanedLines[i][3]))

out = ",".join(advertiseNumbers)
print out


#print GetDistance(lat, long, lat2, long2)

#print IsLessThan(entry, radius)

