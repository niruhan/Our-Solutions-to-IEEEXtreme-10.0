a = []
temp = raw_input()
temp = temp.split(" ")
numPosts = int(temp[1])
for i in range(numPosts):
    new = raw_input()
    a.append([int(new)])
thread = []
target = int(temp[0])


for i in range(len(a)):
    if a[i][0] == 0:
        thread.append(1)
        a[i].append(len(thread) - 1)
    else:
        post = a[i][0]
        page = a[post - 1][1]
        thread[page] += 1
        a[i].append(page)

b=[[]]
z = 0
for i in range(len(thread)):
    if sum(b[z]) < target:
        b[z].append(thread[i])
    else:
        b.append([thread[i]])
        z+=1

sumList = []

for ele in b:
    sumList.append(sum(ele))
#print sumList

maximum = sumList.index(max(sumList))
RHS = abs(b[maximum][-1] + sumList[maximum+1] - target)
#LHS = abs(b[max][0] + sumList[i-1] - target)
print RHS
print abs(maximum-target)
if RHS < abs(maximum-target):
    sumList[maximum] -= b[maximum][-1]
    sumList[maximum+1] += b[maximum][-1]
    b[maximum+1].append(b[maximum][-1])
    b[maximum].__delitem__(-1)


    #print b
    #print sumList

print b
print sumList