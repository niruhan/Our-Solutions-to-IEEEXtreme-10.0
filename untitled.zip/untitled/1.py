
dunno = lambda L: L[-1::] + L[0:len(L) - 1]



def evenNot(inp):
    if not inp % 2:
        return False
    else:
        return True


def pep(N):
    c = tuple(xrange(1, N + 1))
    return c


def live(cps):
    die = 0

    while len(cps) > 1:
        if evenNot(len(cps)):
            die += 1
            cps = cps[::2]
            cps = dunno(cps)

        else:
            die += 1
            cps = cps[::2]

    return cps[0]

num = input()
for q in range(num):
    myInput = input()

    cladiators = pep(myInput)

    print live(cladiators)
