for ele in b:
    sumList.append(sum(ele))
# print sumList

maximum = sumList.index(max(sumList))
RHS = abs(b[maximum][-1] + sumList[maximum + 1] - target)
# LHS = abs(b[max][0] + sumList[i-1] - target)
# print RHS
# print abs(maximum - target)
if RHS < abs(maximum - target):
    sumList[maximum] -= b[maximum][-1]
    sumList[maximum + 1] += b[maximum][-1]
    b[maximum + 1].append(b[maximum][-1])
    b[maximum].__delitem__(-1)